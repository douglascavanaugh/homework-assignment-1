/*
 * Frontend Logic for application
 *
 */

 var app = {};

 console.log("Hello Console World!!");
